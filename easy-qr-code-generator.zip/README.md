# Easy QR Code Generator Plugin
